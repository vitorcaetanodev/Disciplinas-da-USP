Delphi interface to the FFTW Version 3.X libraries
  By Serdar S. Kacar (sskacar_d at hotmail dot com), June 9, 2011
  Based on Mark G. Beckett (g.beckett at epcc.ed.ac.uk ), 22/DEC/03

Tested on Delphi7 against the libraries from
  ftp://ftp.fftw.org/pub/fftw/fftw-3.2.2.pl1-dll32.zip

Supported Libraries :
- fftw_  : Double
- fftwf_ : Single 
- fftwl_ : Extended (i.e. Long Double)

Supported Features :
- Threads
- Wisdom (limited but good enough)
- Basic Interface

Unsupported Features :
- Advanced Interface
- Guru Interface
- Academic stuff
