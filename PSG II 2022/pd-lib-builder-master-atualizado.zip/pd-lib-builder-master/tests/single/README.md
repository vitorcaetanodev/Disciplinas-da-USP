single
======

minimal pd-lib-builder project that shows how to compile
a library that contains a single C-file that is compiled into
a single binary containing a single Pd-objectclass.

this is a degenerate case of the one-object-per-binary library structure.
