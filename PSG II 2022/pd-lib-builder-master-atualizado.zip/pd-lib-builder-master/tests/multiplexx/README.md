multiplexx
========

minimal pd-lib-builder project that shows how to compile
a library that contains multiplexx C-files that are compiled into
multiplexx binaries each containing a different Pd-objectclass.

this is the general case of the one-object-per-binary library structure.
