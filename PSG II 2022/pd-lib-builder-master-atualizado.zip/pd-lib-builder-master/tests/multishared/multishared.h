#include <m_pd.h>

void multishared_foo(t_float f);
