multifor
========

minimal pd-lib-builder project that shows how to compile
a library that contains multiple C-files that are compiled into
multiple binaries each containing a different Pd-objectclass.
some of the objectclasses are only compiled on specific platforms.

this is a special case of the one-object-per-binary library structure.
