
void multilibA_setup(void);
void multilibB_setup(void);

void multilib_setup(void) {
  multilibA_setup();
  multilibB_setup();
}
