multilib
========

minimal pd-lib-builder project that shows how to compile
a library that contains multiple C-files that are compiled into
a single binary containing  different Pd-objectclasses.

this is the general case of the single-binary library structure.
